<!DOCTYPE html>
<html lang="en">
	
	

	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width,height=device-height,initial-scale=1.0"/>
		<meta name="author" content="JAIRI IDRISS">
		<title><?php getTitle(); ?></title>

		

		<link rel="stylesheet" type="text/css" href="Design/css/bootstrap.min.css">

		<link rel="stylesheet" type="text/css" href="Design/fonts/css/all.min.css">
		<link rel="stylesheet" type="text/css" href="Design/css/main.css">
		<link rel="stylesheet" type="text/css" href="Design/css/responsive.css">
		

		
	</head>

	

	<body>
	